<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//RU">

<h3>Feedback #<?php echo e($feedback->id); ?> -<?php echo e($feedback->title); ?></h3>

<table border="0" style="margin:0; padding:0">
    <tr>
        <td>Имя:</td>
        <td><?php echo e($user->name); ?> <?php echo e($user->surname); ?> (<?php echo e($user->nickname); ?>)</td>
    </tr>
    <tr>
        <td>Темa:</td>
        <td><?php echo e($feedback->title); ?></td>
    </tr>
    <tr>
        <td>Сообщение:</td>
        <td><?php echo e($feedback->text); ?></td>
    </tr>
</table>
<?php /**PATH C:\OSPanel\domains\vrisc.su\resources\views/feedbackmail.blade.php ENDPATH**/ ?>