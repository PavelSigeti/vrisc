<template>
    <router-view></router-view>
</template>

<script>
export default {
    name: "ClearLayout"
}
</script>

<style scoped>

</style>
