<template>

</template>

<script>
export default {
    name: "AppHomeStage"
}
</script>

<style scoped>

</style>
